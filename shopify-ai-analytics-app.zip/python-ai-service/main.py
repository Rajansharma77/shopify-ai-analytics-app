from fastapi import FastAPI
from agent.intent_classifier import classify_intent
from agent.shopifyql_generator import generate_query
from agent.response_explainer import explain_response

app = FastAPI()

@app.post("/ask")
def ask(data: dict):
    question = data["question"]
    intent = classify_intent(question)
    query = generate_query(intent)
    answer = explain_response(intent)
    return {
        "answer": answer,
        "confidence": "medium"
    }
