def classify_intent(question):
    q = question.lower()
    if "inventory" in q:
        return "inventory"
    elif "customer" in q:
        return "customers"
    return "sales"
