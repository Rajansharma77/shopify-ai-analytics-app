def explain_response(intent):
    if intent == "inventory":
        return "Based on recent sales, you should reorder inventory for next week."
    elif intent == "customers":
        return "Some customers placed repeat orders recently."
    return "Your top selling products performed well last week."
