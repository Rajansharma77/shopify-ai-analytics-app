def generate_query(intent):
    if intent == "inventory":
        return "FROM inventory SHOW available"
    elif intent == "customers":
        return "FROM customers SHOW count"
    return "FROM sales SHOW total_sales"
