# AI-Powered Shopify Analytics App

## Overview
Assignment-ready mock implementation of an AI-powered analytics app for Shopify.

## Architecture
Rails API -> Python FastAPI AI Agent -> ShopifyQL (mock)

## Tech Stack
- Ruby on Rails (API-only)
- Python (FastAPI)
- ShopifyQL (mock)

## Run
Start Python:
uvicorn main:app --reload

Start Rails:
rails s
