module Api
  module V1
    class QuestionsController < ApplicationController
      def create
        question = params[:question]
        store_id = params[:store_id]

        if question.nil? || store_id.nil?
          render json: { error: "Invalid input" }, status: 400
          return
        end

        response = PythonClient.ask_question(question, store_id)
        render json: response
      end
    end
  end
end
