require 'net/http'
require 'json'

class PythonClient
  def self.ask_question(question, store_id)
    uri = URI("http://localhost:8000/ask")
    response = Net::HTTP.post(
      uri,
      { question: question, store_id: store_id }.to_json,
      "Content-Type" => "application/json"
    )
    JSON.parse(response.body)
  end
end
